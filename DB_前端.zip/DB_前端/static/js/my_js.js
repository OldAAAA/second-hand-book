
function openUrl(url) {
    window.location.href = url;
}